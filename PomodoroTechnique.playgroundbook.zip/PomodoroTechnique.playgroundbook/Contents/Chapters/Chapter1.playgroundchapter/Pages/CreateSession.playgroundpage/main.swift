//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.

import PlaygroundSupport
import UIKit

let page = PlaygroundPage.current
let proxy = page.liveView as! PlaygroundRemoteLiveViewProxy
func sendData() {
    proxy.send(PlaygroundValue.integer(33))
}
//#-end-hidden-code
/*:
# Let's create our first pomodoro session 😱!
You'll notice the layout of our pomodoro playground has changed a little; for instance, we have a new container which will let us know how we are doing during our session. The more we progress with this playground, the more features our session can have! Now, remember that pomodoro session class we discussed earlier? Well, it's time for us to actually use it (Well, sort of)! Let's go ahead and create a session 😁. We're just gonna need a title for the session and the colors you want for the session; let's leave the goals and time aside for a moment. After that go ahead and **run** the code to see the results!
*/

var sessionTitle: String = /*#-editable-code Type a title for your session*/" "/*#-end-editable-code*/
var mainColor: UIColor = /*#-editable-code Select a main color for your session*/ #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1) /*#-end-editable-code*/
var accentColor: UIColor = /*#-editable-code Select an accent color for your session*/ #colorLiteral(red: 0.4745098054, green: 0.8392156959, blue: 0.9764705896, alpha: 1) /*#-end-editable-code*/

//#-hidden-code
let mainRedColor = Double((mainColor.cgColor.components?[0])!)
let mainGreenColor = Double((mainColor.cgColor.components?[1])!)
let mainBlueColor = Double((mainColor.cgColor.components?[2])!)

let accentRedColor = Double((accentColor.cgColor.components?[0])!)
let accentGreenColor = Double((accentColor.cgColor.components?[1])!)
let accentBlueColor = Double((accentColor.cgColor.components?[2])!)
//#-end-hidden-code
//#-hidden-code
//#-end-hidden-code
//#-hidden-code
proxy.send(PlaygroundValue.dictionary([
  "mainRed": PlaygroundValue.floatingPoint(mainRedColor),
  "mainGreen": PlaygroundValue.floatingPoint(mainGreenColor),
  "mainBlue": PlaygroundValue.floatingPoint(mainBlueColor),
  "accentRed": PlaygroundValue.floatingPoint(accentRedColor),
  "accentGreen": PlaygroundValue.floatingPoint(accentGreenColor),
  "accentBlue": PlaygroundValue.floatingPoint(accentBlueColor)
]))
proxy.send(PlaygroundValue.string(sessionTitle))
//#-end-hidden-code
/*:
## AWESOME 🎉!
You have succesfully created your first pomodoro session (High Five!! 🙌). Now let's **tap the timer** and see what happens... You'll see more information about your newly created session. Remember the goals we didn't write about 30 seconds ago? Well, your first goal was to create a session, so tap on the grayed out goal on the timer container and see what happens! 🤩. Each time you create a session from now on, you'll also create goals you plan on achieving by the end of it.
 
 ## Features added to our playground
You see, sometimes when we are focused on our work, there are somethings we can't ignore like a call from our family, work or even school; thankfully we have a pause button (**which you should use only in case you can't ignore that special thing**). So just for knowledge sake **tap on that button** and you will notice our pomodoro session has been paused. It's worth mentioning that **when you pause a session, you won't be able mark as complete your goals, you know, to avoid cheating**. So let us continue on to the [**next and final page**](MakePomodoroYourOwn) (or you could just continue reading for some cool facts).
 
 
 ### Did you know?
 Throught the entire history of the world, managing our time has been a key part in our development as individuals and professionals; according to a study made last year, we spend just a little over 2 hours and a half per day on social media, that sums up to about a month of just scrolling through our timelines in one year 🤯 (that's just social media). And that's not taking into consideration the rough times we live in, where there just aren't many things to do at our homes. So by managing our times we can focus on our personal growth while still enjoying the little things. Anyway, I'm gonna leave the rest up to you 😊; so now let's [keep going](MakePomodoroYourOwn) and finish your first pomodoro session 👌
*/
