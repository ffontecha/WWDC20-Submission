//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.

import PlaygroundSupport
import UIKit

let page = PlaygroundPage.current
let proxy = page.liveView as! PlaygroundRemoteLiveViewProxy
func sendData() {
    proxy.send(PlaygroundValue.integer(33))
}

class PomodoroSession {
    var sessionTitle: String
    var sessionDuration: Int
    var mainColor: UIColor
    var accentColor: UIColor
    var sessionGoals: [PomodoroGoal]
    var isActive: Bool

    /**
    Initializes a new pomodoro session and specifications.

     - Parameters:
        - title: The *title* of the session the user is creating
        - duration: The *duration* of the session **given in seconds**.
        - mainColor: The *mainColor* will define the looks of the session.
        - accentColor: The *accentColor* will define the accent color of the session.
        - goals: The *goals* of the session the user wants to achieve. (optional)

    - Returns: A beautiful, brand-new bicycle,
               custom-built just for you.
    */
    init(sessionTitle: String, sessionDuration: Int, sessionGoals: [PomodoroGoal], mainColor: UIColor, accentColor: UIColor) {
        self.sessionTitle = sessionTitle
        self.sessionDuration = sessionDuration
        self.sessionGoals = sessionGoals
        self.mainColor = mainColor
        self.accentColor = accentColor
        
        isActive = true
    }
}

class PomodoroGoal {
    var goalTitle: String
    var isComplete: Bool

    init(goalTitle: String) {
        self.goalTitle = goalTitle
            
        isComplete = false
    }
}
//#-end-hidden-code
/*:
# Part of the journey is the end 😢
We are finally on the last part of this playground and the time we've had shared is essencial to ensure you will now try to start habits with this pomodoro technique. So far we've learned what the pomodoro technique is and we got familiar with my take on it, you've created your first session and achieved your first of many goals; so now you have full control on what to do next: **MAKE POMODORO YOUR OWN**. So just for old times' sake, I'm gonna walk you through this last page. You are about to fully create your session, so choose every value with your goals in mind 😊.
*/

var sessionTitle: String = /*#-editable-code Type a title for your session*/"Evaluating WWDC20 submissions"/*#-end-editable-code*/
var sessionDuration: Int = /*#-editable-code Type the duration (in minutes) of your session*/25/*#-end-editable-code*/
var mainColor: UIColor = /*#-editable-code Select a main color for your session*/ #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1) /*#-end-editable-code*/
var accentColor: UIColor = /*#-editable-code Select an accent color for your session*/ #colorLiteral(red: 0.4745098054, green: 0.8392156959, blue: 0.9764705896, alpha: 1) /*#-end-editable-code*/

let firstGoal = PomodoroGoal(goalTitle: /*#-editable-code Type a goal for your session*/"Download playgrounds"/*#-end-editable-code*/)
let secondGoal = PomodoroGoal(goalTitle: /*#-editable-code Type a goal for your session*/"Finish my 1st session"/*#-end-editable-code*/)
let thirdGoal = PomodoroGoal(goalTitle: /*#-editable-code Type a goal for your session*/"Managing my time"/*#-end-editable-code*/)
let fourthGoal = PomodoroGoal(goalTitle: /*#-editable-code Type a goal for your session*/"Eat Llunch"/*#-end-editable-code*/)
let fifthGoal = PomodoroGoal(goalTitle: /*#-editable-code Type a goal for your session*/"Approve 7 playgrounds"/*#-end-editable-code*/)
let sixthGoal = PomodoroGoal(goalTitle: /*#-editable-code Type a goal for your session*/"Assist WWDC next year"/*#-end-editable-code*/)

var sessionGoals: [PomodoroGoal] = [firstGoal, secondGoal, thirdGoal, fourthGoal, fifthGoal, sixthGoal]
//#-hidden-code
let mainRedColor = Double((mainColor.cgColor.components?[0])!)
let mainGreenColor = Double((mainColor.cgColor.components?[1])!)
let mainBlueColor = Double((mainColor.cgColor.components?[2])!)

let accentRedColor = Double((accentColor.cgColor.components?[0])!)
let accentGreenColor = Double((accentColor.cgColor.components?[1])!)
let accentBlueColor = Double((accentColor.cgColor.components?[2])!)

let goal1 = firstGoal.goalTitle
let goal2 = secondGoal.goalTitle
let goal3 = thirdGoal.goalTitle
let goal4 = fourthGoal.goalTitle
let goal5 = fifthGoal.goalTitle
let goal6 = sixthGoal.goalTitle
//#-end-hidden-code
//#-hidden-code
//#-end-hidden-code
//#-hidden-code
proxy.send(PlaygroundValue.dictionary([
  "mainRed": PlaygroundValue.floatingPoint(mainRedColor),
  "mainGreen": PlaygroundValue.floatingPoint(mainGreenColor),
  "mainBlue": PlaygroundValue.floatingPoint(mainBlueColor),
  "accentRed": PlaygroundValue.floatingPoint(accentRedColor),
  "accentGreen": PlaygroundValue.floatingPoint(accentGreenColor),
  "accentBlue": PlaygroundValue.floatingPoint(accentBlueColor),
  "goal1": PlaygroundValue.string(goal1),
  "goal2": PlaygroundValue.string(goal2),
  "goal3": PlaygroundValue.string(goal3),
  "goal4": PlaygroundValue.string(goal4),
  "goal5": PlaygroundValue.string(goal5),
  "goal6": PlaygroundValue.string(goal6)
]))
proxy.send(PlaygroundValue.string(sessionTitle))
proxy.send(PlaygroundValue.integer(sessionDuration))
//#-end-hidden-code
/*:
## NICELY DONE 🥳!
You have finally created from scratch your first of many pomodoro sessions, now let me tell you some quick tips about your fresh out of the oven pomodoro session. We now have a *stop button* made for **emergencies only**, be aware that if you tap on it, your ongoing session **will end immediately** 😧! Thankfully this playground has got you covered, in the container where you usually keep track of your goals you'll see the session you created when you last ran the code, so you can re-use that session by tapping on it as long as you do not have an ongoing session.
 
 **Oh! One more thing** feel free to toggle on and off dark mode 🌓 to experience this playground either outside in plain sunlight or indoors going easy on your eyes.
 
 # Thanks for everything
 We had fun, didn't we? I know for sure I had a blast doing this playground. As I told you in the begining of this playground, I like to think that by repeating and achieving activities many times, we can generate habits, so go ahead and try out; the posibilities are endless. I hope this playground brought you closer to wanting to manage your time, or if you already managed your time before this playground, I hope you liked my take on it. Hope to hear from you guys soon! 👋
 
*/
