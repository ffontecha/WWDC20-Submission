//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.

import PlaygroundSupport
import UIKit

let page = PlaygroundPage.current
//#-end-hidden-code
/*:
# Fernando Fontecha's Pomodoro Technique playground!
First things first let me introduce myself: my name is  Fernando Garcia Fontecha Hernandez. I’m a 22 year old student currently enrolled in **Digital Animation Engineering** at Universidad Panamericana and I am also a *programming teacher* in the same school based in Mexico City. This playground is inteded for people who want to manage their time using the **pomodoro technique** while implementing new ideas to the table regarding personal growth. But first we should *answer one important question*, shouldn't we? 🤔

## What exactly is the Pomodoro Techinque?
If you are a developer and are very keen on managing your times, you are on the right place. The Pomodoro Technique, developed by Francesco Cirillo, is a time management method divided mainly in intervals of usualy 25 minutes in which you should only focus on the work you are doing. If you watch closely to your right (or top dependending on the orientation of the device), you'll see an active pomodoro session with about half a minute remaining by the time you get here.
 
So, we should discuss how we created the session, right? We used an instance of the class shown below.
*/
class PomodoroSession {
  var sessionTitle: String?
  var sessionDuration: Int?
  var mainColor: UIColor?
  var accentColor: UIColor?
  var sessionGoals: [PomodoroGoal] = []
  var isActive: Bool?
}
/*:
You might've seen we have **goals** and **colors** associated with our session; that's kind of my personal touch regarding this Playground. Each time you create a session you'll set yourself the goals you plan on achieving by the end of it and as a plus you get to personalize the session with your favorite colors; but first we should discuss how goals are made.
*/
class PomodoroGoal {
  var goalTitle: String?
  var isComplete: Bool?
}
/*:
Okay, so now we know that this is what *dreams* (goals) are made of! (👏 if you got the Lizzie McGuire reference). The main objective of the goals, is to generate habits; I like to think that repeating something and achieving it several times, forges a habit on us. On a sidenote, if you managed to finish reading before the session was over, 🎉 **congratulations, you're off to a great start** 🎉! 🎊 🎉 Now we can move on to the [next page](CreateSession) 😁.
*/
