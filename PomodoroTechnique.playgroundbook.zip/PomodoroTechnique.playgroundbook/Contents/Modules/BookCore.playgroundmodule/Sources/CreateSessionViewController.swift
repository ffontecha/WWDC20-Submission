//
//  CreateSessionViewController.swift
//  BookCore
//
//  Created by Fernando Fontecha on 07/05/20.
//

import UIKit
import PlaygroundSupport

@objc(BookCore_CreateSessionViewController)
class CreateSessionViewController: UIViewController, PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer {
  
  //MARK: Private properties
  // Colors
  private var mainRed: CGFloat?
  private var mainBlue: CGFloat?
  private var mainGreen: CGFloat?

  // Colors for session
  private var accentRed: CGFloat?
  private var accentBlue: CGFloat?
  private var accentGreen: CGFloat?
  private var mainColor: UIColor?
  private var accentColor: UIColor?
  private var sessionTitle: String = "WWDC 2020 Student Challenge"
  
  // Session essentials
  var pomodoroSession: PomodoroSession?
  var seconds: Int = 120
  var timer = Timer()
  var isTimerRunning = false
  var tappedPause = false
  var activeGoals: Double = 0
  
  // Progress bars essentials
  var progressView = UIView()
  var ringProgressView = UIView()
  var timerShapeLayer = CAShapeLayer()
  var percentageShapeLayer = CAShapeLayer()
  var timerGradientLayer = CAGradientLayer()
  var percentageGradientLayer = CAGradientLayer()

  let backgroundRect = CALayer()
  let progressRect = CALayer()
  let progressGradient = CAGradientLayer()
  
  // Constraints for animation
  var timerCountdownX = NSLayoutConstraint()
  var timerCountdownY = NSLayoutConstraint()
  
  //Expanded timer container
  var goalsLabel = UILabel()

  //MARK: Outlets
  @IBOutlet weak var scrollViewContent: UIView!
  @IBOutlet weak var contentStackView: UIStackView!
  @IBOutlet weak var timerTitle: UILabel!
  @IBOutlet weak var timerContainer: UIView!
  @IBOutlet weak var timerLabel: UILabel!
  @IBOutlet weak var timerContainerHeight: NSLayoutConstraint!
  @IBOutlet weak var pauseButton: UIButton!
  
  @IBOutlet weak var menuContainer: UIView!
  @IBOutlet weak var messageGoalsLabel: UILabel!
  @IBOutlet weak var percentageRingView: UIView!
  @IBOutlet weak var percentageLabel: UILabel!
  
  
  @IBOutlet weak var particleView: UIView!
  
  weak var goalsCollectionView: UICollectionView!
  
  // MARK: - Lifecycle methods
  override func viewDidLoad() {
    super.viewDidLoad()
    
    setUpInitialView()
    setUpTimerExpansionView()

    setUpCollectionView()
    
    buttonDesign(for: pauseButton, withRadius: pauseButton.bounds.height/2, color: #colorLiteral(red: 1, green: 0.7811210752, blue: 0.5367822051, alpha: 1))
    
    self.goalsCollectionView.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "MyCell")
    self.goalsCollectionView.alwaysBounceVertical = true
    self.goalsCollectionView.backgroundColor = .clear
    self.goalsCollectionView.dataSource = self
    self.goalsCollectionView.delegate = self
  }
  
  @objc func tappedBackground(_ sender: UITapGestureRecognizer? = nil) {
    if let _ = pomodoroSession {
      progressView.isHidden = false
      UIView.animate(withDuration: 0.5, delay: 0.3, usingSpringWithDamping: 0.8, initialSpringVelocity: 0.3, options: .curveEaseInOut, animations: {
        self.timerContainerHeight.constant = 215
        self.timerLabel.transform = CGAffineTransform(scaleX: 1, y: 1)
        self.timerCountdownX.isActive = false
        self.timerCountdownY.isActive = false
        self.timerContainer.layoutIfNeeded()
  //      self.timerTitle.font = UIFont.systemFont(ofSize: 17, weight: .semibold)
  //      self.timerTitle.layoutIfNeeded()
        self.contentStackView.layoutIfNeeded()
        self.progressView.alpha = 1.0
        self.progressGradient.opacity = 1.0
        self.timerGradientLayer.opacity = 0.0
        self.ringProgressView.alpha = 0.0
      })
      timerGradientLayer.isHidden = true
      ringProgressView.isHidden = true
    }
  }
  
  @objc func tappedTimer(_ sender: UITapGestureRecognizer? = nil) {
    if let _ = pomodoroSession, !tappedPause {
      ringProgressView.isHidden = false
      timerGradientLayer.isHidden = false
      timerGradientLayer.layoutIfNeeded()
      
      UIView.animate(withDuration: 0.5, delay: 0.3, usingSpringWithDamping: 0.8, initialSpringVelocity: 0.3, options: .curveEaseInOut, animations: {
        self.timerContainerHeight.constant = 450
        self.contentStackView.layoutIfNeeded()
        self.timerLabel.transform = CGAffineTransform(scaleX: 0.45, y: 0.45)
        self.timerCountdownX.isActive = true
        self.timerCountdownY.isActive = true
        self.timerContainer.layoutIfNeeded()
        self.contentStackView.layoutIfNeeded()
        self.progressView.alpha = 0.0
        self.timerGradientLayer.opacity = 1.0
        self.ringProgressView.alpha = 1.0
      })
      progressView.isHidden = true
    }
  }
  
  @IBAction func tappedPauseButton(_ sender: UIButton) {    
    if let session = pomodoroSession {
      sender.pressAnimation(toValue: 0.9)
      if !tappedPause {
        sender.setImage(UIImage(named: "play"), for: .normal)
        session.isActive = false
        timer.invalidate()
        tappedPause = true
        timerLabel.textColor = .pomodoroInactiveText
        
        pauseTimerAnimation(forCALayer: progressGradient)
        pauseTimerAnimation(forCALayer: timerGradientLayer)
        
        progressView.isHidden = false
        progressGradient.isHidden = false
        
        UIView.animate(withDuration: 0.5, delay: 0.3, usingSpringWithDamping: 0.8, initialSpringVelocity: 0.3, options: .curveEaseInOut, animations: {
          self.timerContainerHeight.constant = 215
          self.timerLabel.transform = CGAffineTransform(scaleX: 1, y: 1)
          self.timerCountdownX.isActive = false
          self.timerCountdownY.isActive = false
          self.timerContainer.layoutIfNeeded()
          self.contentStackView.layoutIfNeeded()
          self.progressView.alpha = 1.0
          self.progressGradient.opacity = 1.0
          self.timerGradientLayer.opacity = 0.0
          self.ringProgressView.alpha = 0.0
          self.ringProgressView.isHidden = true
          self.timerGradientLayer.isHidden = true
        })
        
      } else {
        sender.setImage(UIImage(named: "pause"), for: .normal)
        session.isActive = true
        runPomodoroSession()
        tappedPause = false
        timerLabel.textColor = .pomodoroActiveText
        
        resumeTimerAnimation(forCALayer: progressGradient)
        resumeTimerAnimation(forCALayer: timerGradientLayer)
      }
    }
  }
  
  public func receive(_ message: PlaygroundValue) {
    pomodoroSession = nil
    particleView.alpha = 0.0
    particleView.isHidden = true
    timerLabel.textColor = .pomodoroActiveText
    timerTitle.textColor = .pomodoroActiveText
    
    if case let .dictionary(dict) = message {
      if case let .floatingPoint(mainRed)? = dict["mainRed"] {
        self.mainRed = CGFloat(mainRed)
      }
      if case let .floatingPoint(mainBlue)? = dict["mainBlue"] {
        self.mainBlue = CGFloat(mainBlue)
      }
      if case let .floatingPoint(mainGreen)? = dict["mainGreen"] {
        self.mainGreen = CGFloat(mainGreen)
      }
      if case let .floatingPoint(accentRed)? = dict["accentRed"] {
        self.accentRed = CGFloat(accentRed)
      }
      if case let .floatingPoint(accentBlue)? = dict["accentBlue"] {
        self.accentBlue = CGFloat(accentBlue)
      }
      if case let .floatingPoint(accentGreen)? = dict["accentGreen"] {
        self.accentGreen = CGFloat(accentGreen)
      }
    }
    
    if case let .string(text) = message {
        switch text {
        case text:
            if text != ""{
              self.timerTitle.text = text
              self.sessionTitle = text
            } else {
              self.timerTitle.text = sessionTitle
          }
        default:
            break
        }
    }
    setUpTimer()
    seconds = 60
    pomodoroSession?.sessionDuration = seconds
    particleView.transform = CGAffineTransform(translationX: 0, y: -view.frame.height)
    timerLabel.text = timeToString(time: TimeInterval(pomodoroSession!.sessionDuration))
    startPomodoroSession()
  }
  

  // MARK: - Private methods
  private func buttonDesign(for button: UIButton, withRadius r: CGFloat, color: UIColor) {
    button.layer.cornerRadius = r
    button.backgroundColor = color
    button.titleLabel?.textColor = .pomodoroActiveText
  }
  
  private func setUpTimerExpansionView() {
    particleView.isHidden = true
    timerCountdownX = NSLayoutConstraint(item: self.timerLabel!, attribute: .centerX, relatedBy: .equal, toItem: self.ringProgressView, attribute: .centerX, multiplier: 1, constant: 0)
    timerCountdownY = NSLayoutConstraint(item: self.timerLabel!, attribute: .centerY, relatedBy: .equal, toItem: self.ringProgressView, attribute: .centerY, multiplier: 1, constant: 0)
    
    let timerTap = UITapGestureRecognizer(target: self, action: #selector(self.tappedTimer(_:)))
    let backgroundTap = UITapGestureRecognizer(target: self, action: #selector(self.tappedBackground(_:)))
    
    timerContainer.addGestureRecognizer(timerTap)
    view.addGestureRecognizer(backgroundTap)
    
    timerContainer.addSubview(ringProgressView)
    timerContainer.addSubview(goalsLabel)
    
    ringProgressView.translatesAutoresizingMaskIntoConstraints = false
    goalsLabel.translatesAutoresizingMaskIntoConstraints = false
    
    NSLayoutConstraint(item: ringProgressView, attribute: .centerX, relatedBy: .equal, toItem: timerContainer, attribute: .centerX, multiplier: 1, constant: 0).isActive = true
    NSLayoutConstraint(item: ringProgressView, attribute: .topMargin, relatedBy: .equal, toItem: timerTitle, attribute: .topMargin, multiplier: 1, constant: 70).isActive = true
    NSLayoutConstraint(item: ringProgressView, attribute: .width, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 220).isActive = true
    NSLayoutConstraint(item: ringProgressView, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 220).isActive = true
    
    NSLayoutConstraint(item: goalsLabel, attribute: .topMargin, relatedBy: .equal, toItem: ringProgressView, attribute: .bottomMargin, multiplier: 1, constant: 30)
      .isActive = true
    NSLayoutConstraint(item: goalsLabel, attribute: .leadingMargin, relatedBy: .equal, toItem: timerContainer, attribute: .leadingMargin, multiplier: 1, constant: 16)
      .isActive = true
    
    goalsLabel.font = UIFont.systemFont(ofSize: 30, weight: .medium)
    goalsLabel.text = "Goals"
    
    ringProgressView.backgroundColor = .clear
    ringProgressView.isHidden = true
  }
  
  /**
  Initializes a new pomodoro session and specifications.

   - Parameters:
      - title: The *title* of the session the user is creating
      - duration: The *duration* of the session **given in seconds**.
      - mainColor: The *mainColor* will define the looks of the session.
      - accentColor: The *accentColor* will define the accent color of the session.
      - goals: The *goals* of the session the user wants to achieve. (optional)

  - Returns: A Pomodoro Session object
  */
  private func createSessionWith(title: String, duration: Int, mainColor: UIColor, accentColor: UIColor, goals: [PomodoroGoal] = []) -> PomodoroSession {
      let seconds = duration * 60
      let pomodoro = PomodoroSession(sessionTitle: title, sessionDuration: seconds, sessionGoals: goals, mainColor: mainColor, accentColor: accentColor)
      return pomodoro
  }
  
  /**
  Initializes a new pomodoro goal.

   - Parameters:
      - goal: The *goal* of the session the user is creating

  - Returns: A Pomodoro Goal to achieve your dreams
  */
  private func createSessionGoal(goal: String) -> PomodoroGoal {
      let goal = PomodoroGoal(goalTitle: goal)
      return goal
  }
  
  private func setUpInitialView() {
    
    timerContainer.layer.cornerRadius = 33
    timerContainer.layer.shadowColor = UIColor.black.cgColor
    timerContainer.layer.shadowOpacity = 0.15
    timerContainer.layer.shadowOffset = .zero
    timerContainer.layer.shadowRadius = 13
    
    menuContainer.layer.cornerRadius = 33
    menuContainer.layer.shadowColor = UIColor.black.cgColor
    menuContainer.layer.shadowOpacity = 0.15
    menuContainer.layer.shadowOffset = .zero
    menuContainer.layer.shadowRadius = 13
    
    percentageRingView.layer.cornerRadius = percentageRingView.frame.height / 2
    percentageRingView.layer.borderColor = #colorLiteral(red: 0.4940779209, green: 0.4941400886, blue: 0.4940567017, alpha: 1)
    percentageRingView.layer.borderWidth = 13
    
    messageGoalsLabel.textAlignment = .center
    messageGoalsLabel.text = "You don't seem to have any ongoing session, create one to keep track of your progress!"
        
    timerContainer.addSubview(progressView)

    progressView.translatesAutoresizingMaskIntoConstraints = false
    
    NSLayoutConstraint(item: progressView, attribute: .leadingMargin, relatedBy: .equal, toItem: timerContainer, attribute: .leadingMargin, multiplier: 1, constant: 16).isActive = true
    NSLayoutConstraint(item: progressView, attribute: .trailingMargin, relatedBy: .equal, toItem: timerContainer, attribute: .trailingMargin, multiplier: 1, constant: -16).isActive = true
    NSLayoutConstraint(item: progressView, attribute: .bottomMargin, relatedBy: .equal, toItem: timerContainer, attribute: .bottomMargin, multiplier: 1, constant: -20).isActive = true
    NSLayoutConstraint(item: progressView, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 20).isActive = true
        
    progressView.backgroundColor = #colorLiteral(red: 0.4940779209, green: 0.4941400886, blue: 0.4940567017, alpha: 1)
    progressView.layer.cornerRadius = 10
  }
  
  private func setUpCollectionView() {
    let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
    layout.sectionInset = UIEdgeInsets(top: 20, left: 10, bottom: 10, right: 10)
    layout.itemSize = CGSize(width: 60, height: 60)
    
    let goalsCollectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
    goalsCollectionView.translatesAutoresizingMaskIntoConstraints = false
    timerContainer.addSubview(goalsCollectionView)
    NSLayoutConstraint.activate([
        goalsLabel.bottomAnchor.constraint(equalTo: goalsCollectionView.topAnchor, constant: -10),
        timerContainer.bottomAnchor.constraint(equalTo: goalsCollectionView.bottomAnchor, constant: 22),
        timerContainer.leadingAnchor.constraint(equalTo: goalsCollectionView.leadingAnchor, constant: -16),
        timerContainer.trailingAnchor.constraint(equalTo: goalsCollectionView.trailingAnchor, constant: 16),
    ])
    self.goalsCollectionView = goalsCollectionView
  }
  
  
  private func pauseTimerAnimation(forCALayer cal: CALayer) {
    let pause = cal.convertTime(CACurrentMediaTime(), from: nil)
    cal.speed = 0.0
    cal.timeOffset = pause
  }
  
  private func resumeTimerAnimation(forCALayer cal: CALayer) {
    let pause = cal.timeOffset
    cal.speed = 1.0
    cal.timeOffset = 0.0
    cal.beginTime = 0.0
    let elapsedTime = cal.convertTime(CACurrentMediaTime(), from: nil) - pause
    cal.beginTime = elapsedTime
  }
  
  
  private func createRingView(forPercentage: Bool, with view: UIView, in destinationView: UIView) {
    if !forPercentage {
      view.isHidden = false
      goalsCollectionView.reloadData()
    }

    let center = view.center
    let radius: CGFloat = forPercentage ? 37 : 100
    let circularPath = UIBezierPath(arcCenter: center, radius: radius, startAngle: -CGFloat.pi/2, endAngle: (55 *  CGFloat.pi) / 36, clockwise: true)
    
    view.layer.cornerRadius = view.frame.height / 2
    view.layer.borderColor = forPercentage ? (pomodoroSession?.accentColor)!.withAlphaComponent(0.3).cgColor : UIColor.pomodoroProgressBackground.cgColor
    view.layer.borderWidth = forPercentage ? 15 : 20
    
    if !forPercentage {
      timerShapeLayer.path = circularPath.cgPath
    } else {
      percentageShapeLayer.path = circularPath.cgPath
    }
    
    if !forPercentage {
      timerShapeLayer.strokeColor = UIColor.black.cgColor
      timerShapeLayer.lineWidth = 20
      timerShapeLayer.fillColor = UIColor.clear.cgColor
      timerShapeLayer.lineCap = .round
      timerShapeLayer.frame = view.bounds

      timerShapeLayer.strokeEnd = 0
      
      view.layer.addSublayer(timerShapeLayer)
      
      timerGradientLayer.startPoint = CGPoint(x: 0, y: 0)
      timerGradientLayer.endPoint = CGPoint(x: 1, y: 1)
      timerGradientLayer.colors = [UIColor(red: mainRed!, green: mainGreen!, blue: mainBlue!, alpha: 1.0).cgColor, UIColor(red: accentRed!, green: accentGreen!, blue: accentBlue!, alpha: 1.0).cgColor]
      timerGradientLayer.frame = CGRect(x: 0, y: 0, width: 385, height: 523)
      timerGradientLayer.mask = timerShapeLayer
    } else {
      percentageShapeLayer.strokeColor = UIColor.black.cgColor
      percentageShapeLayer.lineWidth = 7
      percentageShapeLayer.fillColor = UIColor.clear.cgColor
      percentageShapeLayer.lineCap = .round
      percentageShapeLayer.frame = view.bounds
      
      percentageShapeLayer.strokeEnd = 0
      
      view.layer.addSublayer(percentageShapeLayer)
      
      percentageGradientLayer.startPoint = CGPoint(x: 0, y: 0)
      percentageGradientLayer.endPoint = CGPoint(x: 1, y: 1)
      percentageGradientLayer.colors = [UIColor(red: mainRed!, green: mainGreen!, blue: mainBlue!, alpha: 1.0).cgColor, UIColor(red: accentRed!, green: accentGreen!, blue: accentBlue!, alpha: 1.0).cgColor]
      percentageGradientLayer.frame = menuContainer.bounds
      percentageGradientLayer.mask = percentageShapeLayer
    }
        
    destinationView.layer.addSublayer(forPercentage ? percentageGradientLayer : timerGradientLayer)
    if !forPercentage {
      view.isHidden = true
      timerGradientLayer.isHidden = true
    }
  }
  
  private func animateRing(forPercentage: Bool) {
    let basicAnimation = CABasicAnimation(keyPath: "strokeEnd")
    
    if !forPercentage {
      basicAnimation.toValue = 1.0
      basicAnimation.fillMode = .forwards
      basicAnimation.duration = Double(seconds)
      basicAnimation.isRemovedOnCompletion = false
      
      timerShapeLayer.add(basicAnimation, forKey: "timerAnimation")
    } else {
      basicAnimation.fromValue = activeGoals
      guard let goalsArr = pomodoroSession?.sessionGoals else { return }
      let goalsAchieved: Double = Double(goalsArr.filter{$0.isComplete}.count)
      activeGoals = goalsAchieved
      basicAnimation.toValue = (goalsAchieved / Double(goalsArr.count))
      basicAnimation.duration = 0.5
      basicAnimation.fillMode = .forwards
      basicAnimation.isRemovedOnCompletion = false
      
      percentageShapeLayer.add(basicAnimation, forKey: "percentageAnimation")
    }
  }
  
  private func setUpTimer() {
    tappedPause = false
    pauseButton.setImage(UIImage(named: "pause"), for: .normal)
    let goal = createSessionGoal(goal: "Create a session!")
    let inputColor1: UIColor = UIColor(red: mainRed!, green: mainGreen!, blue: mainBlue!, alpha: 1.0)
    let inputColor2: UIColor = UIColor(red: accentRed!, green: accentGreen!, blue: accentBlue!, alpha: 1.0)
    pomodoroSession = createSessionWith(
        title: sessionTitle,
        duration: 1,
        mainColor: inputColor1,
        accentColor: inputColor2,
        goals: [goal]
    )
    
    if let session = pomodoroSession {
        seconds = session.sessionDuration
    }
    
    particleView.alpha = 0.0
    createParticles()

    particleView.transform = CGAffineTransform(translationX: 0, y: -view.frame.height)
    timerLabel.text = timeToString(time: TimeInterval(seconds))
    
    timerContainer.layer.cornerRadius = 33
    timerContainer.layer.shadowColor = UIColor.black.cgColor
    timerContainer.layer.shadowOpacity = 0.15
    timerContainer.layer.shadowOffset = .zero
    timerContainer.layer.shadowRadius = 13
    
    progressRect.bounds = progressView.layer.bounds
    progressGradient.frame = progressRect.bounds
    progressGradient.colors = [(pomodoroSession?.mainColor)!.cgColor, (pomodoroSession?.accentColor)!.cgColor]
    progressGradient.startPoint = CGPoint(x: 0,y: 0)
    progressGradient.endPoint = CGPoint(x: 1,y: 1)
    progressGradient.cornerRadius = 10
    progressRect.insertSublayer(progressGradient, at: 1)
    
    progressRect.cornerRadius = progressView.layer.cornerRadius
    
    progressRect.position = CGPoint(x: 0, y: 0)
    progressGradient.position = progressRect.position

    progressRect.anchorPoint = CGPoint(x: 0, y: 0)
    progressGradient.anchorPoint = progressRect.anchorPoint

    progressView.layer.addSublayer(progressGradient)
    progressView.layer.addSublayer(progressRect)
    
    UIView.animate(withDuration: 0.5, delay: 0.3, usingSpringWithDamping: 0.8, initialSpringVelocity: 0.3, options: .curveEaseInOut, animations: {
      self.progressView.backgroundColor = #colorLiteral(red: 0.831372549, green: 0.831372549, blue: 0.831372549, alpha: 1)
    })
    buttonDesign(for: pauseButton, withRadius: pauseButton.bounds.height/2, color: .systemOrange)
    
    createRingView(forPercentage: false, with: ringProgressView, in: timerContainer)
    createRingView(forPercentage: true, with: percentageRingView, in: menuContainer)
    messageGoalsLabel.text = "You have not achieved your first goal, keep going! 😊"
  }
  
  private func animateProgressBar(for sec: Int) {
    let anim = CABasicAnimation(keyPath: "bounds")

    if pomodoroSession!.isActive {
      anim.duration = CFTimeInterval(sec)
      anim.fromValue = NSValue(cgRect: CGRect(x: 0, y: 0, width: 0, height: 20))
      anim.toValue = NSValue(cgRect: CGRect(x: 0, y: 0, width: 350, height: 20))
      progressGradient.add(anim, forKey: "anim")
      animateRing(forPercentage: false)
    } else {
      anim.duration = CFTimeInterval(0.3)
      anim.fromValue = NSValue(cgRect: CGRect(x: 0, y: 0, width: 350, height: 20))
      anim.toValue = NSValue(cgRect: CGRect(x: 0, y: 0, width: 0, height: 20))
      progressGradient.add(anim, forKey: "anim")
    }
  }
  
  private func runPomodoroSession() {
    if pomodoroSession!.isActive {
      timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: (#selector(updateTimer)), userInfo: nil, repeats: true)
    }
  }
  
  private func startPomodoroSession() {
    if pomodoroSession!.isActive {
      timer.invalidate()
      timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: (#selector(updateTimer)), userInfo: nil, repeats: true)
      animateProgressBar(for: seconds)
      animateRing(forPercentage: false)
    }
  }
  
  @objc private func updateTimer() {
      
      if seconds < 1 {
          timer.invalidate()
          pomodoroSession?.isActive = false
      } else if pomodoroSession!.isActive {
          if seconds == 1 {
              UIView.animate(withDuration: 1.5) {
                  self.particleView.isHidden = false
                  self.particleView.alpha = 1.0
                  self.particleView.transform = CGAffineTransform(translationX: 0, y: 0)
                  self.shake(view: self.contentStackView)
              }
          }
          seconds -= 1
          timerLabel.text = timeToString(time: TimeInterval(seconds))
      }
  }
  
  private func createParticles() {
      let particleEmitter = CAEmitterLayer()

      particleEmitter.emitterPosition = CGPoint(x: particleView.bounds.midX, y: -90)
      particleEmitter.emitterShape = .line
      particleEmitter.emitterSize = CGSize(width: particleView.frame.size.width * 2, height: 1)

      let red = makeEmitterCell(color: #colorLiteral(red: 0.9098039269, green: 0.4784313738, blue: 0.6431372762, alpha: 1), xAcceleration: 50.0, yAcceleration: 400.0)
      let green = makeEmitterCell(color: #colorLiteral(red: 0.721568644, green: 0.8862745166, blue: 0.5921568871, alpha: 1), xAcceleration: -50.0, yAcceleration: 200.0)
      let blue = makeEmitterCell(color: #colorLiteral(red: 0.5568627715, green: 0.3529411852, blue: 0.9686274529, alpha: 1), xAcceleration: 140.0, yAcceleration: 300.0)

      particleEmitter.emitterCells = [red, green, blue]

      particleView.layer.addSublayer(particleEmitter)
  }
  
  private func makeEmitterCell(color: UIColor, xAcceleration xA: Float, yAcceleration yA: Float) -> CAEmitterCell {
      let cell = CAEmitterCell()
      cell.birthRate = 3
      cell.lifetime = 7.5
      cell.lifetimeRange = 0
      cell.xAcceleration = CGFloat(xA)
      cell.yAcceleration = CGFloat(yA)
      cell.color = color.cgColor
      cell.velocity = 100
      cell.velocityRange = 50
      cell.emissionLongitude = CGFloat.pi
      cell.emissionRange = CGFloat.pi / 4
      cell.spin = 2
      cell.spinRange = 3
      cell.scaleRange = 0.5
      cell.scaleSpeed = -0.05

      cell.contents = UIImage(named: "particle_confetti")?.cgImage
      return cell
  }
  
  private func shake(view: UIView) {
      let moveAnimation = CABasicAnimation(keyPath: "position")
      moveAnimation.duration = 0.07
      moveAnimation.repeatCount = 4
      moveAnimation.autoreverses = true
      moveAnimation.fromValue = NSValue(cgPoint: CGPoint(x: view.center.x - 10, y: view.center.y + 10))
      moveAnimation.toValue = NSValue(cgPoint: CGPoint(x: view.center.x + 10, y: view.center.y - 10))
      
      view.layer.add(moveAnimation, forKey: "position")
      view.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
      view.transform = CGAffineTransform.identity
  }
  
  private func timeToString(time: TimeInterval) -> String {
      let hours = Int(time) / 3600
      let minutes = Int(time) / 60 % 60
      let seconds = Int(time) % 60
      
      let timeString = String(format:"%02i:%02i:%02i", hours, minutes, seconds)
      
      return timeString
  }

}


// MARK: - UICollectionViewDataSource
extension CreateSessionViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
      return pomodoroSession?.sessionGoals.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
      let myCell = collectionView.dequeueReusableCell(withReuseIdentifier: "MyCell", for: indexPath)
      let goalLabel = UILabel()
      myCell.contentView.subviews.forEach { $0.removeFromSuperview() }
      goalLabel.translatesAutoresizingMaskIntoConstraints = false
      
      goalLabel.text = pomodoroSession?.sessionGoals[indexPath.row].goalTitle
      myCell.addSubview(goalLabel)
      
      NSLayoutConstraint.activate([
          myCell.centerXAnchor.constraint(equalTo: goalLabel.centerXAnchor),
          myCell.contentView.centerYAnchor.constraint(equalTo: goalLabel.centerYAnchor),
      ])
      
      myCell.layer.cornerRadius = 8
      myCell.backgroundColor = pomodoroSession?.accentColor.withAlphaComponent(0.3)
      myCell.layer.borderColor = pomodoroSession?.mainColor.withAlphaComponent(0.3).cgColor
      myCell.layer.borderWidth = 4
      return myCell
    }
}


// MARK: - UICollectionViewDelegate
extension CreateSessionViewController: UICollectionViewDelegate {
 
  func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {

  }
  
  func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
    UIView.animate(withDuration: 0.3) {
      if let cell = self.goalsCollectionView.cellForItem(at: indexPath) {
        cell.transform = CGAffineTransform(scaleX: 0.95, y: 0.95)
      }
    }
  }

  func collectionView(_ collectionView: UICollectionView, didUnhighlightItemAt indexPath: IndexPath) {
    UIView.animate(withDuration: 0.4, delay: 0, usingSpringWithDamping: 0.6, initialSpringVelocity: 0.3, options: .curveEaseInOut, animations: {
      if let cell = self.goalsCollectionView.cellForItem(at: indexPath) {
        if !(self.pomodoroSession?.sessionGoals[indexPath.row].isComplete)! {
          cell.backgroundColor = (self.pomodoroSession?.accentColor)!.withAlphaComponent(0.5)
          cell.layer.borderColor = self.pomodoroSession?.mainColor.cgColor
          self.pomodoroSession?.sessionGoals[indexPath.row].isComplete.toggle()
        } else {
          cell.backgroundColor = (self.pomodoroSession?.accentColor)!.withAlphaComponent(0.3)
          cell.layer.borderColor = (self.pomodoroSession?.mainColor)!.withAlphaComponent(0.3).cgColor
          self.pomodoroSession?.sessionGoals[indexPath.row].isComplete.toggle()
        }
        self.animateRing(forPercentage: true)
        cell.transform = .identity
      }
    })
    let percentage = Int(activeGoals / Double((pomodoroSession?.sessionGoals.count)!) * 100)
    if activeGoals == Double((pomodoroSession?.sessionGoals.count)!) {
      messageGoalsLabel.text = "OH... MY... GOD! You've achieved your first goal, you are a ROCKSTAR! 🤩"
    } else if activeGoals == 0 {
      messageGoalsLabel.text = "You have not achieved any of your \((pomodoroSession?.sessionGoals.count)!) goals, keep going! 😊"
    } else {
      messageGoalsLabel.text = MotivationMessage.randomMotivationMessage() + "\(Int(activeGoals)) of your \((pomodoroSession?.sessionGoals.count)!)" + MessageEnd.randomEndingMessage()
    }
    percentageLabel.textAlignment = .center
    percentageLabel.text = "\(percentage)%"
  }
}

// MARK: - UICollectionViewDelegateFlowLayout
extension CreateSessionViewController: UICollectionViewDelegateFlowLayout {

    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 165, height: 50)
    }

    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0) //.zero
    }

    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }

    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
}
