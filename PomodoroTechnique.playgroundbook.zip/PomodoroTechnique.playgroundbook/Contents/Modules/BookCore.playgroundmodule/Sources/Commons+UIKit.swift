//
//  Commons+UIColor.swift
//  BookCore
//
//  Created by Fernando Fontecha on 07/05/20.
//

import Foundation
import UIKit

extension UIColor {
  static var pomodoroBackground: UIColor { return UIColor(named: "Background") ?? .white }
  static var pomodoroInactiveBacground: UIColor { return UIColor(named: "InactiveBackground") ?? .white}
  static var pomodoroCardBackground: UIColor { return UIColor(named: "CardBackground") ?? .white }
  static var pomodoroProgressBackground: UIColor { return UIColor(named: "ProgressBackground") ?? .white }
  static var pomodoroActiveText: UIColor { return UIColor(named: "ActiveText") ?? .white }
  static var pomodoroInactiveText: UIColor { return UIColor(named: "InactiveText") ?? .white }
  static var pomodoroInactiveStop: UIColor { return UIColor(named: "InactiveStop") ?? .white }
  static var pomodoroInactivePause: UIColor { return UIColor(named: "InactivePause") ?? .white}
}

extension UIView {
  func pressAnimation(toValue: Double) {
    let animation = CABasicAnimation(keyPath: "transform.scale")
    animation.duration = 0.2
    animation.fromValue = 1.0
    animation.toValue = toValue
    animation.autoreverses = true
    
    self.layer.add(animation, forKey: nil)
  }
}
