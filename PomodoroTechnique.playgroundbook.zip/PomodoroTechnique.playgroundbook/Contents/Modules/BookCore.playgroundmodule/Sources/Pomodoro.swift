//
//  Pomodoro.swift
//  BookCore
//
//  Created by Fernando Fontecha on 07/05/20.
//

import Foundation
import UIKit

class PomodoroSession {
    var sessionTitle: String
    var sessionDuration: Int
    var mainColor: UIColor
    var accentColor: UIColor
    var sessionGoals: [PomodoroGoal]
    var isActive: Bool

    init(sessionTitle: String, sessionDuration: Int, sessionGoals: [PomodoroGoal], mainColor: UIColor, accentColor: UIColor) {
        self.sessionTitle = sessionTitle
        self.sessionDuration = sessionDuration
        self.sessionGoals = sessionGoals
        self.mainColor = mainColor
        self.accentColor = accentColor
        
        isActive = true
    }
}

class PomodoroGoal {
    var goalTitle: String
    var isComplete: Bool

    init(goalTitle: String) {
        self.goalTitle = goalTitle
            
        isComplete = false
    }
}

enum MotivationMessage: String {
  case none = "You have not achieved any of your "
  case nice = "🙌 Nicely done; so far you've achieved "
  case neutral = "Up until now, you've achieved "
  case cool = "You can do better! This time you've achieved "
  case awesome = "OH... MY... GOD! You've achieved all of your "
  
  static func randomMotivationMessage() -> String {
    let possibleMessages = [MotivationMessage.nice, .neutral, .cool]
    let index = Int(arc4random_uniform(UInt32(possibleMessages.count)))
    let message = possibleMessages[index].rawValue
    
    return message
  }
}

enum MessageEnd: String {
  case none = " goals, keep going! 😊"
  case good = " GOOD JOB! ✌️"
  case highFive = " Keep it going! High five 🙌"
  case cool = " You're SO CLOSE! C'mon, you can do it!"
  case awesome = " you are a ROCKSTAR! 🤩"
  
  static func randomEndingMessage() -> String {
    let possibleMessages = [MessageEnd.good, .highFive, .cool]
    let index = Int(arc4random_uniform(UInt32(possibleMessages.count)))
    let message = possibleMessages[index].rawValue
    
    return message
  }
}
