//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  Provides supporting functions for setting up a live view.
//

import UIKit
import PlaygroundSupport

/// Instantiates a new instance of the first session view.
///
/// By default, this loads an instance of `FirstSessionViewController` from `FirstSession.storyboard`.
public func instantiateFirstSessionView() -> PlaygroundLiveViewable {
    let storyboard = UIStoryboard(name: "FirstSession", bundle: nil)

    guard let viewController = storyboard.instantiateInitialViewController() else {
        fatalError("FirstSession.storyboard does not have an initial scene; please set one or update this function")
    }

    guard let liveViewController = viewController as? FirstSessionViewController else {
        fatalError("FirstSession.storyboard's initial scene is not a FirstSessionViewController; please either update the storyboard or this function")
    }

    return liveViewController
}

/// Instantiates a new instance of a create session view.
///
/// By default, this loads an instance of `CreateSessionViewController` from `CreateSession.storyboard`.
public func instantiateCreateSessionView() -> PlaygroundLiveViewable {
    let storyboard = UIStoryboard(name: "CreateSession", bundle: nil)

    guard let viewController = storyboard.instantiateInitialViewController() else {
        fatalError("CreateSession.storyboard does not have an initial scene; please set one or update this function")
    }

    guard let liveViewController = viewController as? CreateSessionViewController else {
        fatalError("CreateSession.storyboard's initial scene is not a CreateSessionViewController; please either update the storyboard or this function")
    }

    return liveViewController
}

/// Instantiates a new instance of a make pomodoro view.
///
/// By default, this loads an instance of `MakePomodoroViewController` from `MakePomodoro.storyboard`.
public func instantiateMakePomodoroView() -> PlaygroundLiveViewable {
    let storyboard = UIStoryboard(name: "MakePomodoro", bundle: nil)

    guard let viewController = storyboard.instantiateInitialViewController() else {
        fatalError("MakePomodoro.storyboard does not have an initial scene; please set one or update this function")
    }

    guard let liveViewController = viewController as? MakePomodoroViewController else {
        fatalError("MakePomodoro.storyboard's initial scene is not a CreateSessionViewController; please either update the storyboard or this function")
    }

    return liveViewController
}
