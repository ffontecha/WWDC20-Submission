//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  An auxiliary source file which is part of the book-level auxiliary sources.
//  Provides the implementation of the "always-on" live view.
//

import UIKit
import PlaygroundSupport

@objc(BookCore_FirstSessionViewController)
public class FirstSessionViewController: UIViewController, PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer {
    
    
    // MARK: Variables and constants
  
    var pomodoroSession: PomodoroSession?
    var seconds: Int = 120
    var timer = Timer()
    var isTimerRunning = false
    var shouldRunSmooth = false
    
    let backgroundRect = CALayer()
    let progressRect = CALayer()
    let progressGradient = CAGradientLayer()
    
    // MARK: Outlets
    @IBOutlet weak var timerLabel: UILabel!
    @IBOutlet weak var timerContainer: UIView!
    @IBOutlet weak var particleView: UIView!
    
    @IBOutlet weak var timeSet: UIView!
    @IBOutlet weak var timeSetLabel: UILabel!
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        setupView()
        runTimer(activeSeconds: seconds)
    }
    
    /*
    public func liveViewMessageConnectionOpened() {
        // Implement this method to be notified when the live view message connection is opened.
        // The connection will be opened when the process running Contents.swift starts running and listening for messages.
    }
    */

    /*
    public func liveViewMessageConnectionClosed() {
        // Implement this method to be notified when the live view message connection is closed.
        // The connection will be closed when the process running Contents.swift exits and is no longer listening for messages.
        // This happens when the user's code naturally finishes running, if the user presses Stop, or if there is a crash.
    }
    */

    
    // MARK: Functions and methods
    public func receive(_ message: PlaygroundValue) {
        timer.invalidate()
        particleView.alpha = 0.0
        particleView.isHidden = true
        // Implement this method to receive messages sent from the process running Contents.swift.
        if case let .string(text) = message {
            switch text {
            case text:
                if text != ""{
                    self.timerLabel.text = text
                }
            default:
                break
            }
        } else if case let .integer(number) = message {
            switch number {
            case number:
                seconds = number * 60
                pomodoroSession?.sessionDuration = seconds
                particleView.transform = CGAffineTransform(translationX: 0, y: -view.frame.height)
                timerLabel.text = timeToString(time: TimeInterval(pomodoroSession!.sessionDuration))
                runTimer(activeSeconds: seconds)
            default:
                break
            }
        }
        // This method is *required* by the PlaygroundLiveViewMessageHandler protocol.
        // Use this method to decode any messages sent as PlaygroundValue values and respond accordingly.
    }
    
    
    /// Initializes a new  pomodoroSession object from the given parameters.
    ///
    /// - Parameters:
    ///     - title: The *title* of the session the user is creating
    ///     - duration: The *duration* of the session **given in minutes**.
    ///     - mainColor: The *mainColor* will define the looks of the session.
    ///     - accentColor: The *accentColor* will define the accent color of the session.
    ///     - goals: The *goals* of the session the user wants to achieve. (optional)
    /// - Returns: A pomodoro session made for you
    func createSessionWith(title: String, duration: Int, mainColor: UIColor, accentColor: UIColor, goals: [PomodoroGoal] = []) -> PomodoroSession {
        let seconds = duration * 60
        let pomodoro = PomodoroSession(sessionTitle: title, sessionDuration: seconds, sessionGoals: goals, mainColor: mainColor, accentColor: accentColor)
        return pomodoro
    }
    
    func createSessionGoal(goal: String) -> PomodoroGoal {
        let goal = PomodoroGoal(goalTitle: goal)
        return goal
    }
    
    // MARK: Private methods
    private func setupView() {
        let goal = createSessionGoal(goal: "Finish reading!")
        let inputColor1: UIColor = #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1)
        let inputColor2: UIColor = #colorLiteral(red: 0.4745098054, green: 0.8392156959, blue: 0.9764705896, alpha: 1)
        pomodoroSession = createSessionWith(
            title: "WWDC20 Student Challenge",
            duration: 1,
            mainColor: inputColor1,
            accentColor: inputColor2,
            goals: [goal]
        )
        
        if let session = pomodoroSession {
            seconds = session.sessionDuration
        }
        
        timeSetLabel.text = timeToString(time: TimeInterval(seconds))
        
        particleView.alpha = 0.0
        createParticles()

        particleView.transform = CGAffineTransform(translationX: 0, y: -view.frame.height)
        timerLabel.text = timeToString(time: TimeInterval(seconds))
        
        timeSet.layer.cornerRadius = timeSet.frame.height/2
        timeSet.layer.shadowColor = UIColor.black.cgColor
        timeSet.layer.shadowOpacity = 0.15
        timeSet.layer.shadowOffset = .zero
        timeSet.layer.shadowRadius = 13
        
        timerContainer.layer.cornerRadius = 33
        timerContainer.layer.shadowColor = UIColor.black.cgColor
        timerContainer.layer.shadowOpacity = 0.15
        timerContainer.layer.shadowOffset = .zero
        timerContainer.layer.shadowRadius = 13
        
        backgroundRect.bounds = CGRect(x: 0, y: 0, width: 350, height: 20)
        backgroundRect.cornerRadius = backgroundRect.bounds.height / 2
        backgroundRect.backgroundColor = #colorLiteral(red: 0.831372549, green: 0.831372549, blue: 0.831372549, alpha: 1)
        
        progressRect.bounds = backgroundRect.bounds
        progressGradient.frame = progressRect.bounds
        progressGradient.colors = [(pomodoroSession?.mainColor)!.cgColor, (pomodoroSession?.accentColor)!.cgColor]
        progressGradient.startPoint = CGPoint(x: 0,y: 0)
        progressGradient.endPoint = CGPoint(x: 1,y: 1)
        progressGradient.cornerRadius = 10
        progressRect.insertSublayer(progressGradient, at: 1)
        
        progressRect.cornerRadius = backgroundRect.cornerRadius
        
        backgroundRect.position = CGPoint(x: 16, y: timerContainer.bounds.height - 45)
        progressRect.position = backgroundRect.position
        progressGradient.position = backgroundRect.position

        backgroundRect.anchorPoint = CGPoint(x: 0, y: 0)
        progressRect.anchorPoint = backgroundRect.anchorPoint
        progressGradient.anchorPoint = backgroundRect.anchorPoint

        timerContainer.layer.addSublayer(backgroundRect)
        timerContainer.layer.addSublayer(progressGradient)
        timerContainer.layer.addSublayer(progressRect)
    }
    
    private func createParticles() {
        let particleEmitter = CAEmitterLayer()

        particleEmitter.emitterPosition = CGPoint(x: particleView.bounds.midX, y: -90)
        particleEmitter.emitterShape = .line
        particleEmitter.emitterSize = CGSize(width: particleView.frame.size.width * 2, height: 1)

        let red = makeEmitterCell(color: #colorLiteral(red: 0.9098039269, green: 0.4784313738, blue: 0.6431372762, alpha: 1), xAcceleration: 50.0, yAcceleration: 400.0)
        let green = makeEmitterCell(color: #colorLiteral(red: 0.721568644, green: 0.8862745166, blue: 0.5921568871, alpha: 1), xAcceleration: -50.0, yAcceleration: 200.0)
        let blue = makeEmitterCell(color: #colorLiteral(red: 0.5568627715, green: 0.3529411852, blue: 0.9686274529, alpha: 1), xAcceleration: 140.0, yAcceleration: 300.0)

        particleEmitter.emitterCells = [red, green, blue]

        particleView.layer.addSublayer(particleEmitter)
    }

    private func makeEmitterCell(color: UIColor, xAcceleration xA: Float, yAcceleration yA: Float) -> CAEmitterCell {
        let cell = CAEmitterCell()
        cell.birthRate = 3
        cell.lifetime = 7.5
        cell.lifetimeRange = 0
        cell.xAcceleration = CGFloat(xA)
        cell.yAcceleration = CGFloat(yA)
        cell.color = color.cgColor
        cell.velocity = 100
        cell.velocityRange = 50
        cell.emissionLongitude = CGFloat.pi
        cell.emissionRange = CGFloat.pi / 4
        cell.scaleRange = 0.5
        cell.scaleSpeed = -0.05

        cell.contents = UIImage(named: "particle_confetti")?.cgImage
        return cell
    }

    private func runTimer(activeSeconds sec: Int) {
        let anim = CABasicAnimation(keyPath: "bounds")
        
        if pomodoroSession!.isActive {
            timer.invalidate()
            timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: (#selector(updateTimer)), userInfo: nil, repeats: true)
            
            anim.duration = CFTimeInterval(sec)
            anim.fromValue = NSValue(cgRect: CGRect(x: 0, y: 0, width: 0, height: 20))
            anim.toValue = NSValue(cgRect: CGRect(x: 0, y: 0, width: 350, height: 20))
            progressGradient.add(anim, forKey: "anim")
        } else {
           anim.duration = CFTimeInterval(0.3)
           anim.fromValue = NSValue(cgRect: CGRect(x: 0, y: 0, width: 350, height: 20))
           anim.toValue = NSValue(cgRect: CGRect(x: 0, y: 0, width: 0, height: 20))
           progressGradient.add(anim, forKey: "anim")
       }
    }
    
    @objc private func updateTimer() {
        
        if seconds < 1 {
            timer.invalidate()
            pomodoroSession?.isActive = false
        } else if pomodoroSession!.isActive {
            if seconds == 1 {
                UIView.animate(withDuration: 1.5) {
                    self.particleView.isHidden = false
                    self.particleView.alpha = 1.0
                    self.particleView.transform = CGAffineTransform(translationX: 0, y: 0)
                    self.shake(view: self.timerContainer)
                }
            }
            seconds -= 1
            timerLabel.text = timeToString(time: TimeInterval(seconds))
        }
    }
    
    private func shake(view: UIView) {
        let moveAnimation = CABasicAnimation(keyPath: "position")
        moveAnimation.duration = 0.07
        moveAnimation.repeatCount = 4
        moveAnimation.autoreverses = true
        moveAnimation.fromValue = NSValue(cgPoint: CGPoint(x: view.center.x - 10, y: view.center.y + 10))
        moveAnimation.toValue = NSValue(cgPoint: CGPoint(x: view.center.x + 10, y: view.center.y - 10))
        
        view.layer.add(moveAnimation, forKey: "position")
        view.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
        view.transform = CGAffineTransform.identity
    }
    
    private func timeToString(time: TimeInterval) -> String {
        let hours = Int(time) / 3600
        let minutes = Int(time) / 60 % 60
        let seconds = Int(time) % 60
        
        let timeString = String(format:"%02i:%02i:%02i", hours, minutes, seconds)
        
        return timeString
    }
    
    
}
