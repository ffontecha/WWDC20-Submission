//
//  MakePomodoroViewController.swift
//  BookCore
//
//  Created by Fernando Fontecha on 10/05/20.
//

import UIKit
import PlaygroundSupport

@objc(BookCore_MakePomodoroViewController)
class MakePomodoroViewController: UIViewController, PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer {
  
  //MARK: Private Properties
  // Colors
  private var mainRed: CGFloat?
  private var mainBlue: CGFloat?
  private var mainGreen: CGFloat?

  // Colors for session
  private var accentRed: CGFloat?
  private var accentBlue: CGFloat?
  private var accentGreen: CGFloat?
  private var mainColor: UIColor?
  private var accentColor: UIColor?
  private var sessionTitle: String = "WWDC 2020 Student Challenge"
  private var borderLayer: CAShapeLayer?
  
  // Session essentials
  private var goals: [PomodoroGoal] = []
  private var pomodoroSession: PomodoroSession?
  private var cachePomodoroSession: PomodoroSession?
  private var seconds: Int = 0
  private var timer = Timer()
  private var isTimerRunning = false
  private var tappedPause = false
  private var tappedStop = false
  private var activeGoals: Double = 0
  
  // Progress bars essentials
  var progressView = UIView()
  var ringProgressView = UIView()
  var timerShapeLayer = CAShapeLayer()
  var percentageShapeLayer = CAShapeLayer()
  var timerGradientLayer = CAGradientLayer()
  var percentageGradientLayer = CAGradientLayer()

  let backgroundRect = CALayer()
  let progressRect = CALayer()
  let progressGradient = CAGradientLayer()
  
  // Constraints for animation
  var timerCountdownX = NSLayoutConstraint()
  var timerCountdownY = NSLayoutConstraint()
  
  //Expanded timer container
  var goalsLabel = UILabel()

  //MARK: Outlets
  @IBOutlet weak var contentStackView: UIStackView!
  @IBOutlet weak var timerTitle: UILabel!
  @IBOutlet weak var timerContainer: UIView!
  @IBOutlet weak var timerLabel: UILabel!
  @IBOutlet weak var timerContainerHeight: NSLayoutConstraint!
  @IBOutlet weak var pauseButton: UIButton!
  @IBOutlet weak var stopButton: UIButton!
  
  @IBOutlet weak var menuContainer: UIView!
  @IBOutlet weak var noSessionToShowLabel: UILabel!
  @IBOutlet weak var sessionView: UIView!
  @IBOutlet weak var sessionTitleLabel: UILabel!
  @IBOutlet weak var sessionDuration: UILabel!
  @IBOutlet weak var messageGoalsLabel: UILabel!
  @IBOutlet weak var percentageRingView: UIView!
  @IBOutlet weak var percentageLabel: UILabel!
    
  @IBOutlet weak var particleView: UIView!
  
  weak var goalsCollectionView: UICollectionView!
  
  // MARK: - Lifecycle methods
  override func viewDidLoad() {
    super.viewDidLoad()
    
    setUpInitialView()
    setUpTimerExpansionView()

    // Do any additional setup after loading the view.
    setUpCollectionView()
    setUpSessionCellView()
    
    buttonDesign(for: stopButton, withRadius: 8.0, color: .pomodoroInactiveStop)
    buttonDesign(for: pauseButton, withRadius: pauseButton.bounds.height/2, color: .pomodoroInactivePause)
    
    self.goalsCollectionView.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "MyCell")
    self.goalsCollectionView.alwaysBounceVertical = true
    self.goalsCollectionView.backgroundColor = .clear
    self.goalsCollectionView.dataSource = self
    self.goalsCollectionView.delegate = self
  }
  
  @objc func tappedBackground(_ sender: UITapGestureRecognizer? = nil) {
      progressView.isHidden = false
      UIView.animate(withDuration: 0.5, delay: 0.3, usingSpringWithDamping: 0.8, initialSpringVelocity: 0.3, options: .curveEaseInOut, animations: {
        self.timerContainerHeight.constant = 215
        self.timerLabel.transform = CGAffineTransform(scaleX: 1, y: 1)
        self.timerCountdownX.isActive = false
        self.timerCountdownY.isActive = false
        self.timerGradientLayer.opacity = 0.0
        self.ringProgressView.alpha = 0.0
        self.progressView.alpha = 1.0
        self.progressGradient.opacity = 1.0
        self.timerContainer.layoutIfNeeded()
        self.contentStackView.layoutIfNeeded()
      })
      ringProgressView.isHidden = true
      timerGradientLayer.isHidden = true
  }
  
  @objc func tappedTimer(_ sender: UITapGestureRecognizer? = nil) {
    if let _ = pomodoroSession, !tappedPause {
      ringProgressView.isHidden = false
      timerGradientLayer.isHidden = ringProgressView.isHidden
      timerGradientLayer.layoutIfNeeded()
      
      UIView.animate(withDuration: 0.5, delay: 0.3, usingSpringWithDamping: 0.8, initialSpringVelocity: 0.3, options: .curveEaseInOut, animations: {
        self.timerContainerHeight.constant = 530
        self.timerLabel.transform = CGAffineTransform(scaleX: 0.45, y: 0.45)
        self.timerCountdownX.isActive = true
        self.timerCountdownY.isActive = true
        self.timerGradientLayer.opacity = 1.0
        self.ringProgressView.alpha = 1.0
        self.progressView.alpha = 0.0
        self.timerContainer.layoutIfNeeded()
        self.contentStackView.layoutIfNeeded()
      })
      progressView.isHidden = true
    }
  }
  
  @objc func tappedSession(_ sender: UITapGestureRecognizer? = nil) {
    if let _ = cachePomodoroSession, (pomodoroSession == nil) || (seconds == 0) {
      stopButton.isEnabled = true
      pauseButton.isEnabled = true
      pauseButton.backgroundColor = .systemOrange
      stopButton.backgroundColor = .systemRed
      sessionView.pressAnimation(toValue: 0.95)
      pomodoroSession = cachePomodoroSession
      tappedPause = false
      progressGradient.isHidden = false
      pomodoroSession?.isActive = true
      
      setUpTimer(forSession: pomodoroSession!)
      start(PomodoroSession: pomodoroSession!)
      percentageRingView.layer.borderColor = (pomodoroSession?.accentColor)!.withAlphaComponent(0.5).cgColor
    }
  }
  
  @IBAction func tappedPauseButton(_ sender: UIButton) {
    if let _ = pomodoroSession, seconds > 0 {
      sender.pressAnimation(toValue: 0.9)
      
      if !tappedPause {
        sender.setImage(UIImage(named: "play"), for: .normal)
        pomodoroSession!.isActive = false
        timer.invalidate()
        tappedPause = true
        stopButton.backgroundColor = .pomodoroInactiveStop
        timerLabel.textColor = .pomodoroInactiveText
        
        pauseTimerAnimation(forCALayer: progressGradient)
        pauseTimerAnimation(forCALayer: timerGradientLayer)
        
        progressView.isHidden = false
        progressGradient.isHidden = false

        UIView.animate(withDuration: 0.5, delay: 0.3, usingSpringWithDamping: 0.8, initialSpringVelocity: 0.3, options: .curveEaseInOut, animations: {
          self.timerContainerHeight.constant = 215
          self.timerLabel.transform = CGAffineTransform(scaleX: 1, y: 1)
          self.timerCountdownX.isActive = false
          self.timerCountdownY.isActive = false
          self.timerContainer.layoutIfNeeded()
          self.contentStackView.layoutIfNeeded()
          self.progressView.alpha = 1.0
          self.progressGradient.opacity = 1.0
          self.timerGradientLayer.opacity = 0.0
          self.ringProgressView.alpha = 0.0
          self.ringProgressView.isHidden = true
          self.timerGradientLayer.isHidden = true
        })
        
      } else {
        sender.setImage(UIImage(named: "pause"), for: .normal)
        pomodoroSession!.isActive = true
        resumePomodoroSession()
        tappedPause = false
        stopButton.backgroundColor = .systemRed
        timerLabel.textColor = .pomodoroActiveText

        resumeTimerAnimation(forCALayer: progressGradient)
        resumeTimerAnimation(forCALayer: timerGradientLayer)
      }
    }
  }
  
  @IBAction func tappedStopButton(_ sender: UIButton) {
    if let _ = pomodoroSession, !tappedPause {
      sender.pressAnimation(toValue: 0.9)
      tappedStop = true
      timer.invalidate()
      pomodoroSession = nil
      timerLabel.text = "00:00:00"
      timerLabel.textColor = .pomodoroInactiveText
      timerTitle.text = "No current session active"
      timerTitle.textColor = .pomodoroInactiveText
      seconds = 0
      progressView.backgroundColor = #colorLiteral(red: 0.4940779209, green: 0.4941400886, blue: 0.4940567017, alpha: 1)
      percentageRingView.layer.borderColor = #colorLiteral(red: 0.4940779209, green: 0.4941400886, blue: 0.4940567017, alpha: 1)
      percentageRingView.layer.borderWidth = 16
      ringProgressView.isHidden = true
      timerGradientLayer.isHidden = ringProgressView.isHidden
      progressView.isHidden = false
      progressGradient.isHidden = true
      UIView.animate(withDuration: 0.5, delay: 0.3, usingSpringWithDamping: 0.8, initialSpringVelocity: 0.3, options: .curveEaseInOut, animations: {
        self.timerContainerHeight.constant = 215
        self.timerLabel.transform = CGAffineTransform(scaleX: 1, y: 1)
        self.timerCountdownX.isActive = false
        self.timerCountdownY.isActive = false
        self.progressView.alpha = 1.0
        self.timerContainer.layoutIfNeeded()
        self.contentStackView.layoutIfNeeded()
      })
      percentageGradientLayer.isHidden = true
      messageGoalsLabel.textAlignment = .center
      messageGoalsLabel.text = "You don't seem to have any ongoing session, create one or tap on an exisiting one to keep track of your progress!"
      percentageLabel.text = "0%"
      
      stopButton.backgroundColor = .pomodoroInactiveStop
      pauseButton.backgroundColor = .pomodoroInactivePause
    }
  }
  
  
  public func receive(_ message: PlaygroundValue) {
      particleView.alpha = 0.0
      particleView.isHidden = true
      timerLabel.textColor = .pomodoroActiveText
      timerTitle.textColor = .pomodoroActiveText
      
      if case let .dictionary(dict) = message {
        goals = []
        if case let .floatingPoint(mainRed)? = dict["mainRed"] {
          self.mainRed = CGFloat(mainRed)
        }
        if case let .floatingPoint(mainBlue)? = dict["mainBlue"] {
          self.mainBlue = CGFloat(mainBlue)
        }
        if case let .floatingPoint(mainGreen)? = dict["mainGreen"] {
          self.mainGreen = CGFloat(mainGreen)
        }
        if case let .floatingPoint(accentRed)? = dict["accentRed"] {
          self.accentRed = CGFloat(accentRed)
        }
        if case let .floatingPoint(accentBlue)? = dict["accentBlue"] {
          self.accentBlue = CGFloat(accentBlue)
        }
        if case let .floatingPoint(accentGreen)? = dict["accentGreen"] {
          self.accentGreen = CGFloat(accentGreen)
        }
        if case let .string(goal1)? = dict["goal1"] {
          if !goal1.isEmpty {
            self.goals.append(PomodoroGoal(goalTitle: goal1))
          }
        }
        if case let .string(goal2)? = dict["goal2"] {
          if !goal2.isEmpty {
            self.goals.append(PomodoroGoal(goalTitle: goal2))
          }
        }
        if case let .string(goal3)? = dict["goal3"] {
          if !goal3.isEmpty {
            self.goals.append(PomodoroGoal(goalTitle: goal3))
          }
        }
        if case let .string(goal4)? = dict["goal4"] {
          if !goal4.isEmpty {
            self.goals.append(PomodoroGoal(goalTitle: goal4))
          }
        }
        if case let .string(goal5)? = dict["goal5"] {
          if !goal5.isEmpty {
            self.goals.append(PomodoroGoal(goalTitle: goal5))
          }
        }
        if case let .string(goal6)? = dict["goal6"] {
          if !goal6.isEmpty {
            self.goals.append(PomodoroGoal(goalTitle: goal6))
          }
        }
      }
      
      if case let .string(text) = message {
          switch text {
          case text:
              if text != ""{
                self.timerTitle.text = text
                self.sessionTitle = text
              } else {
                self.timerTitle.text = sessionTitle
            }
          default:
              break
          }
      } else if case let .integer(number) = message {
          switch number {
          case number:
            seconds = number * 60
            particleView.transform = CGAffineTransform(translationX: 0, y: -view.frame.height)
          default:
              break
          }
      }
      let inputColor1: UIColor = UIColor(red: mainRed!, green: mainGreen!, blue: mainBlue!, alpha: 1.0)
      let inputColor2: UIColor = UIColor(red: accentRed!, green: accentGreen!, blue: accentBlue!, alpha: 1.0)
      pomodoroSession = createSessionWith(
          title: sessionTitle,
          duration: seconds,
          mainColor: inputColor1,
          accentColor: inputColor2,
          goals: goals
      )
      goalsCollectionView.reloadData()
      cachePomodoroSession = pomodoroSession
      setUpTimer(forSession: pomodoroSession!)
      particleView.transform = CGAffineTransform(translationX: 0, y: -view.frame.height)
      timerLabel.text = timeToString(time: TimeInterval(pomodoroSession!.sessionDuration))
      start(PomodoroSession: pomodoroSession!)
      createRingView(forPercentage: false, with: ringProgressView, in: timerContainer)
      createRingView(forPercentage: true, with: percentageRingView, in: menuContainer)
      ringProgressView.alpha = 0.0
      updateSessionCellView()
    }
  
  // MARK: - Private Methods
  private func setUpSessionCellView() {
    sessionTitleLabel.isHidden = true
    sessionDuration.isHidden = true
    noSessionToShowLabel.textColor = .pomodoroInactiveText
    
    self.borderLayer?.removeFromSuperlayer()
    sessionView.layer.cornerRadius = 12.0
    
    let borderLayer = CAShapeLayer()
    borderLayer.strokeColor = UIColor.pomodoroInactiveText.cgColor
    borderLayer.lineDashPattern = [9, 9]
    borderLayer.frame = sessionView.bounds
    borderLayer.fillColor = UIColor.clear.cgColor
    borderLayer.path = UIBezierPath(roundedRect: sessionView.bounds, cornerRadius: 12.0).cgPath
    
    self.borderLayer = borderLayer
    sessionView.layer.addSublayer(borderLayer)

  }
  
  private func updateSessionCellView() {
    if let pomodoro = pomodoroSession {
      noSessionToShowLabel.isHidden = true
      sessionTitleLabel.isHidden = false
      sessionDuration.isHidden = false
      
      sessionTitleLabel.text = pomodoro.sessionTitle
      sessionDuration.text = "\((pomodoro.sessionDuration)/60) min"
      
      
      let sessionGradient = CAGradientLayer()
      
      sessionGradient.startPoint = CGPoint(x: 0, y: 0)
      sessionGradient.endPoint = CGPoint(x: 1, y: 1)
      sessionGradient.colors = [UIColor(red: mainRed!, green: mainGreen!, blue: mainBlue!, alpha: 1.0).cgColor, UIColor(red: accentRed!, green: accentGreen!, blue: accentBlue!, alpha: 1.0).cgColor]
      sessionGradient.frame = sessionView.bounds
      sessionGradient.cornerRadius = 12.0
      borderLayer?.isHidden = true
      
      sessionView.layer.insertSublayer(sessionGradient, at: 0)
    }
  }
  
  private func buttonDesign(for button: UIButton, withRadius r: CGFloat, color: UIColor) {
    button.layer.cornerRadius = r
    button.backgroundColor = color
    button.titleLabel?.textColor = .pomodoroActiveText
  }
  
  private func setUpTimerExpansionView() {
    particleView.isHidden = true
    timerCountdownX = NSLayoutConstraint(item: self.timerLabel!, attribute: .centerX, relatedBy: .equal, toItem: self.ringProgressView, attribute: .centerX, multiplier: 1, constant: 0)
    timerCountdownY = NSLayoutConstraint(item: self.timerLabel!, attribute: .centerY, relatedBy: .equal, toItem: self.ringProgressView, attribute: .centerY, multiplier: 1, constant: 0)
    
    let timerTap = UITapGestureRecognizer(target: self, action: #selector(self.tappedTimer(_:)))
    let backgroundTap = UITapGestureRecognizer(target: self, action: #selector(self.tappedBackground(_:)))
    let sessionTap = UITapGestureRecognizer(target: self, action: #selector(self.tappedSession(_:)))

    sessionView.addGestureRecognizer(sessionTap)
    timerContainer.addGestureRecognizer(timerTap)
    view.addGestureRecognizer(backgroundTap)
    
    timerContainer.addSubview(ringProgressView)
    timerContainer.addSubview(goalsLabel)
    
    ringProgressView.translatesAutoresizingMaskIntoConstraints = false
    goalsLabel.translatesAutoresizingMaskIntoConstraints = false
    
    NSLayoutConstraint(item: ringProgressView, attribute: .centerX, relatedBy: .equal, toItem: timerContainer, attribute: .centerX, multiplier: 1, constant: 0).isActive = true
    NSLayoutConstraint(item: ringProgressView, attribute: .topMargin, relatedBy: .equal, toItem: timerTitle, attribute: .topMargin, multiplier: 1, constant: 70).isActive = true
    NSLayoutConstraint(item: ringProgressView, attribute: .width, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 220).isActive = true
    NSLayoutConstraint(item: ringProgressView, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 220).isActive = true
    
    NSLayoutConstraint(item: goalsLabel, attribute: .topMargin, relatedBy: .equal, toItem: ringProgressView, attribute: .bottomMargin, multiplier: 1, constant: 30)
      .isActive = true
    NSLayoutConstraint(item: goalsLabel, attribute: .leadingMargin, relatedBy: .equal, toItem: timerContainer, attribute: .leadingMargin, multiplier: 1, constant: 16)
      .isActive = true
    
    goalsLabel.font = UIFont.systemFont(ofSize: 30, weight: .medium)
    goalsLabel.text = "Goals"
    
    ringProgressView.backgroundColor = .clear
    ringProgressView.isHidden = true
    timerGradientLayer.isHidden = ringProgressView.isHidden
  }
  
  private func pauseTimerAnimation(forCALayer cal: CALayer) {
    let pause = cal.convertTime(CACurrentMediaTime(), from: nil)
    cal.speed = 0.0
    cal.timeOffset = pause
  }
  
  private func resumeTimerAnimation(forCALayer cal: CALayer) {
    let pause = cal.timeOffset
    cal.speed = 1.0
    cal.timeOffset = 0.0
    cal.beginTime = 0.0
    let elapsedTime = cal.convertTime(CACurrentMediaTime(), from: nil) - pause
    cal.beginTime = elapsedTime
  }
  
  private func stopAnimation(forCALayer cal: CALayer) {
    cal.speed = 0.0
  }
  
  private func createRingView(forPercentage: Bool, with view: UIView, in destinationView: UIView) {
    if !forPercentage {
      view.isHidden = false
      goalsCollectionView.reloadData()
    }
    // Track layer
    let center = view.center
    let radius: CGFloat = forPercentage ? 37 : 100
    let circularPath = UIBezierPath(arcCenter: center, radius: radius, startAngle: -CGFloat.pi/2, endAngle: (55 *  CGFloat.pi) / 36, clockwise: true)
    
    view.layer.cornerRadius = view.frame.height / 2
    view.layer.borderColor = forPercentage ? (pomodoroSession?.accentColor)!.withAlphaComponent(0.3).cgColor : UIColor.pomodoroProgressBackground.cgColor
    view.layer.borderWidth = forPercentage ? 16 : 20
    
    if !forPercentage {
      timerShapeLayer.path = circularPath.cgPath
    } else {
      percentageShapeLayer.path = circularPath.cgPath
    }
    
    // Progress mask
    if !forPercentage {
      timerShapeLayer.strokeColor = UIColor.black.cgColor
      timerShapeLayer.lineWidth = 20
      timerShapeLayer.fillColor = UIColor.clear.cgColor
      timerShapeLayer.lineCap = .round
      timerShapeLayer.frame = view.bounds

      timerShapeLayer.strokeEnd = 0
      
      view.layer.addSublayer(timerShapeLayer)
      
      timerGradientLayer.startPoint = CGPoint(x: 0, y: 0)
      timerGradientLayer.endPoint = CGPoint(x: 1, y: 1)
      timerGradientLayer.colors = [UIColor(red: mainRed!, green: mainGreen!, blue: mainBlue!, alpha: 1.0).cgColor, UIColor(red: accentRed!, green: accentGreen!, blue: accentBlue!, alpha: 1.0).cgColor]
      timerGradientLayer.frame = CGRect(x: 0, y: 0, width: 385, height: 523)
      timerGradientLayer.mask = timerShapeLayer
    } else {
      percentageShapeLayer.strokeColor = UIColor.black.cgColor
      percentageShapeLayer.lineWidth = 7
      percentageShapeLayer.fillColor = UIColor.clear.cgColor
      percentageShapeLayer.lineCap = .round
      percentageShapeLayer.frame = view.bounds
      
      percentageShapeLayer.strokeEnd = 0
      
      view.layer.addSublayer(percentageShapeLayer)
      
      percentageGradientLayer.startPoint = CGPoint(x: 0, y: 0)
      percentageGradientLayer.endPoint = CGPoint(x: 1, y: 1)
      percentageGradientLayer.colors = [UIColor(red: mainRed!, green: mainGreen!, blue: mainBlue!, alpha: 1.0).cgColor, UIColor(red: accentRed!, green: accentGreen!, blue: accentBlue!, alpha: 1.0).cgColor]
      percentageGradientLayer.frame = menuContainer.bounds
      percentageGradientLayer.mask = percentageShapeLayer
    }
        
    // Gradient layer
    destinationView.layer.addSublayer(forPercentage ? percentageGradientLayer : timerGradientLayer)
    if !forPercentage {
      view.isHidden = true
    }
  }
  
  /**
  Initializes a new pomodoro session and specifications.

   - Parameters:
      - title: The *title* of the session the user is creating
      - duration: The *duration* of the session **given in seconds**.
      - mainColor: The *mainColor* will define the looks of the session.
      - accentColor: The *accentColor* will define the accent color of the session.
      - goals: The *goals* of the session the user wants to achieve. (optional)

  - Returns: A Pomodoro Session object
  */
  private func createSessionWith(title: String, duration: Int, mainColor: UIColor, accentColor: UIColor, goals: [PomodoroGoal] = []) -> PomodoroSession {
      let seconds = duration
      let pomodoro = PomodoroSession(sessionTitle: title, sessionDuration: seconds, sessionGoals: goals, mainColor: mainColor, accentColor: accentColor)
      return pomodoro
  }
  
  /**
  Initializes a new pomodoro goal.

   - Parameters:
      - goal: The *goal* of the session the user is creating

  - Returns: A Pomodoro Goal to achieve your dreams
  */
  private func createSessionGoal(goal: String) -> PomodoroGoal {
      let goal = PomodoroGoal(goalTitle: goal)
      return goal
  }
  
  private func setUpInitialView() {
    
    timerContainer.layer.cornerRadius = 33
    timerContainer.layer.shadowColor = UIColor.black.cgColor
    timerContainer.layer.shadowOpacity = 0.15
    timerContainer.layer.shadowOffset = .zero
    timerContainer.layer.shadowRadius = 13
    
    menuContainer.layer.cornerRadius = 33
    menuContainer.layer.shadowColor = UIColor.black.cgColor
    menuContainer.layer.shadowOpacity = 0.15
    menuContainer.layer.shadowOffset = .zero
    menuContainer.layer.shadowRadius = 13
    
    percentageRingView.layer.cornerRadius = percentageRingView.frame.height / 2
    percentageRingView.layer.borderColor = #colorLiteral(red: 0.4940779209, green: 0.4941400886, blue: 0.4940567017, alpha: 1)
    percentageRingView.layer.borderWidth = 16
    
    messageGoalsLabel.textAlignment = .center
    messageGoalsLabel.text = "You don't seem to have any ongoing session, create one to keep track of your progress!"
    
    // createRingView(forPercentage: true, with: ringProgressView, in: menuContainer)
    
    timerContainer.addSubview(progressView)

    progressView.translatesAutoresizingMaskIntoConstraints = false
    
    NSLayoutConstraint(item: progressView, attribute: .leadingMargin, relatedBy: .equal, toItem: timerContainer, attribute: .leadingMargin, multiplier: 1, constant: 16).isActive = true
    NSLayoutConstraint(item: progressView, attribute: .trailingMargin, relatedBy: .equal, toItem: timerContainer, attribute: .trailingMargin, multiplier: 1, constant: -16).isActive = true
    NSLayoutConstraint(item: progressView, attribute: .bottomMargin, relatedBy: .equal, toItem: timerContainer, attribute: .bottomMargin, multiplier: 1, constant: -20).isActive = true
    NSLayoutConstraint(item: progressView, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 20).isActive = true
        
    progressView.backgroundColor = #colorLiteral(red: 0.4940779209, green: 0.4941400886, blue: 0.4940567017, alpha: 1)
    progressView.layer.cornerRadius = 10
  }
  
  private func setUpCollectionView() {
    let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
    layout.sectionInset = UIEdgeInsets(top: 20, left: 10, bottom: 10, right: 10)
    layout.itemSize = CGSize(width: 60, height: 60)
    
    let goalsCollectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
    goalsCollectionView.translatesAutoresizingMaskIntoConstraints = false
    timerContainer.addSubview(goalsCollectionView)
    NSLayoutConstraint.activate([
        goalsLabel.bottomAnchor.constraint(equalTo: goalsCollectionView.topAnchor, constant: -10),
        timerContainer.bottomAnchor.constraint(equalTo: goalsCollectionView.bottomAnchor, constant: 22),
        timerContainer.leadingAnchor.constraint(equalTo: goalsCollectionView.leadingAnchor, constant: -16),
        timerContainer.trailingAnchor.constraint(equalTo: goalsCollectionView.trailingAnchor, constant: 16),
    ])
    self.goalsCollectionView = goalsCollectionView
  }
  
  private func setUpTimer(forSession session: PomodoroSession) {
    particleView.alpha = 0.0
    createParticles()

    particleView.transform = CGAffineTransform(translationX: 0, y: -view.frame.height)
    timerLabel.text = timeToString(time: TimeInterval(session.sessionDuration))
    
    timerContainer.layer.cornerRadius = 33
    timerContainer.layer.shadowColor = UIColor.black.cgColor
    timerContainer.layer.shadowOpacity = 0.15
    timerContainer.layer.shadowOffset = .zero
    timerContainer.layer.shadowRadius = 13
    
    progressRect.bounds = progressView.layer.bounds
    progressGradient.frame = progressRect.bounds
    progressGradient.colors = [(pomodoroSession?.mainColor)!.cgColor, (pomodoroSession?.accentColor)!.cgColor]
    progressGradient.startPoint = CGPoint(x: 0,y: 0)
    progressGradient.endPoint = CGPoint(x: 1,y: 1)
    progressGradient.cornerRadius = 10
    progressRect.insertSublayer(progressGradient, at: 1)
    
    progressRect.cornerRadius = progressView.layer.cornerRadius
    
    progressRect.position = CGPoint(x: 0, y: 0)
    progressGradient.position = progressRect.position

    progressRect.anchorPoint = CGPoint(x: 0, y: 0)
    progressGradient.anchorPoint = progressRect.anchorPoint

    progressView.layer.addSublayer(progressGradient)
    progressView.layer.addSublayer(progressRect)
    
    UIView.animate(withDuration: 0.5, delay: 0.3, usingSpringWithDamping: 0.8, initialSpringVelocity: 0.3, options: .curveEaseInOut, animations: {
      self.progressView.backgroundColor = #colorLiteral(red: 0.831372549, green: 0.831372549, blue: 0.831372549, alpha: 1)
    })
    buttonDesign(for: stopButton, withRadius: 8.0, color: .systemRed)
    buttonDesign(for: pauseButton, withRadius: pauseButton.bounds.height/2, color: .systemOrange)
    
    messageGoalsLabel.text = "You have not achieved any of your \((pomodoroSession?.sessionGoals.count)!) goal(s), keep going! 😊"
  }
  
  private func animateRing(forPercentage: Bool) {
    let basicAnimation = CABasicAnimation(keyPath: "strokeEnd")
    
    if !forPercentage {
      basicAnimation.speed = 1.0
      basicAnimation.toValue = 1.0
      basicAnimation.fillMode = .forwards
      basicAnimation.duration = Double(seconds + 1)
      basicAnimation.isRemovedOnCompletion = false
      
      timerShapeLayer.add(basicAnimation, forKey: "timerAnimation")
    } else {
      percentageGradientLayer.isHidden = false
      guard let goalsArr = pomodoroSession?.sessionGoals else { return }
      let goalsAchieved: Double = Double(goalsArr.filter{$0.isComplete}.count)
      basicAnimation.fillMode = .forwards
      basicAnimation.fromValue = (activeGoals / Double(goalsArr.count))
      activeGoals = goalsAchieved
      basicAnimation.toValue = (goalsAchieved / Double(goalsArr.count))
      basicAnimation.duration = 0.3
      basicAnimation.isRemovedOnCompletion = false
      
      percentageShapeLayer.add(basicAnimation, forKey: "percentageAnimation")
    }
  }
  
  private func animateProgressBar(for sec: Int) {
    let anim = CABasicAnimation(keyPath: "bounds")
    anim.speed = 1.0
    progressGradient.isHidden = false
    
    if pomodoroSession!.isActive {
      anim.duration = CFTimeInterval(sec)
      anim.fromValue = NSValue(cgRect: CGRect(x: 0, y: 0, width: 0, height: 20))
      anim.toValue = NSValue(cgRect: CGRect(x: 0, y: 0, width: 350, height: 20))
      progressGradient.add(anim, forKey: "anim")
      animateRing(forPercentage: false)
    } else {
      anim.duration = CFTimeInterval(0.3)
      anim.fromValue = NSValue(cgRect: CGRect(x: 0, y: 0, width: 350, height: 20))
      anim.toValue = NSValue(cgRect: CGRect(x: 0, y: 0, width: 0, height: 20))
      progressGradient.add(anim, forKey: "anim")
    }
  }
  
  private func resumePomodoroSession() {
    if pomodoroSession!.isActive {
      timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: (#selector(updateTimer)), userInfo: nil, repeats: true)
    }
  }
  
  private func start(PomodoroSession session: PomodoroSession) {
    if session.isActive {
      timer.invalidate()
      pomodoroSession = session
      seconds = session.sessionDuration
      
      timerTitle.textColor = .pomodoroActiveText
      timerLabel.textColor = .pomodoroActiveText
      UIView.animate(withDuration: 0.5) {
        self.progressView.backgroundColor = #colorLiteral(red: 0.831372549, green: 0.831372549, blue: 0.831372549, alpha: 1)
        self.percentageRingView.layer.borderColor = #colorLiteral(red: 0.831372549, green: 0.831372549, blue: 0.831372549, alpha: 1)
      }
      
      timerLabel.text = timeToString(time: TimeInterval(seconds))
      timerTitle.text = session.sessionTitle

      timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: (#selector(updateTimer)), userInfo: nil, repeats: true)
      animateProgressBar(for: session.sessionDuration)
      animateRing(forPercentage: false)
    }
  }
  
  @objc private func updateTimer() {
      if seconds < 1 {
        timer.invalidate()
        pomodoroSession?.isActive = false
        stopButton.backgroundColor = .pomodoroInactiveStop
        pauseButton.backgroundColor = .pomodoroInactivePause
        stopButton.isEnabled = false
        pauseButton.isEnabled = false
        UIView.animate(withDuration: 0.8, delay: 10, animations: {
          self.particleView.alpha = 0.0
          self.particleView.transform = CGAffineTransform(translationX: 0, y: -self.view.frame.height)
        })

        
      } else if pomodoroSession!.isActive {
        if seconds == 1 {
          UIView.animate(withDuration: 1.5) {
            self.particleView.isHidden = false
            self.particleView.alpha = 1.0
            self.particleView.transform = CGAffineTransform(translationX: 0, y: 0)
            self.shake(view: self.contentStackView)
          }
        }
        seconds -= 1
        timerLabel.text = timeToString(time: TimeInterval(seconds))
      }
  }
  
  private func createParticles() {
      let particleEmitter = CAEmitterLayer()

      particleEmitter.emitterPosition = CGPoint(x: particleView.bounds.midX, y: -90)
      particleEmitter.emitterShape = .line
      particleEmitter.emitterSize = CGSize(width: particleView.frame.size.width * 2, height: 1)

      let red = makeEmitterCell(color: #colorLiteral(red: 0.9098039269, green: 0.4784313738, blue: 0.6431372762, alpha: 1), xAcceleration: 50.0, yAcceleration: 400.0)
      let green = makeEmitterCell(color: #colorLiteral(red: 0.721568644, green: 0.8862745166, blue: 0.5921568871, alpha: 1), xAcceleration: -50.0, yAcceleration: 200.0)
      let blue = makeEmitterCell(color: #colorLiteral(red: 0.5568627715, green: 0.3529411852, blue: 0.9686274529, alpha: 1), xAcceleration: 140.0, yAcceleration: 300.0)

      particleEmitter.emitterCells = [red, green, blue]

      particleView.layer.addSublayer(particleEmitter)
  }
  
  private func makeEmitterCell(color: UIColor, xAcceleration xA: Float, yAcceleration yA: Float) -> CAEmitterCell {
      let cell = CAEmitterCell()
      cell.birthRate = 3
      cell.lifetime = 7.5
      cell.lifetimeRange = 0
      cell.xAcceleration = CGFloat(xA)
      cell.yAcceleration = CGFloat(yA)
      cell.color = color.cgColor
      cell.velocity = 100
      cell.velocityRange = 50
      cell.emissionLongitude = CGFloat.pi
      cell.emissionRange = CGFloat.pi / 4
      cell.spin = 2
      cell.spinRange = 3
      cell.scaleRange = 0.5
      cell.scaleSpeed = -0.05

      cell.contents = UIImage(named: "particle_confetti")?.cgImage
      return cell
  }
  
  private func shake(view: UIView) {
      let moveAnimation = CABasicAnimation(keyPath: "position")
      moveAnimation.duration = 0.07
      moveAnimation.repeatCount = 4
      moveAnimation.autoreverses = true
      moveAnimation.fromValue = NSValue(cgPoint: CGPoint(x: view.center.x - 10, y: view.center.y + 10))
      moveAnimation.toValue = NSValue(cgPoint: CGPoint(x: view.center.x + 10, y: view.center.y - 10))
      
      view.layer.add(moveAnimation, forKey: "position")
      view.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
      view.transform = CGAffineTransform.identity
  }
  
  private func timeToString(time: TimeInterval) -> String {
      let hours = Int(time) / 3600
      let minutes = Int(time) / 60 % 60
      let seconds = Int(time) % 60
      
      let timeString = String(format:"%02i:%02i:%02i", hours, minutes, seconds)
      
      return timeString
  }

}

// MARK: - UICollectionViewDataSource
extension MakePomodoroViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
      return pomodoroSession?.sessionGoals.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
      let myCell = collectionView.dequeueReusableCell(withReuseIdentifier: "MyCell", for: indexPath)
      let goalLabel = UILabel()
      myCell.contentView.subviews.forEach { $0.removeFromSuperview() }
      goalLabel.translatesAutoresizingMaskIntoConstraints = false
      
      goalLabel.text = pomodoroSession?.sessionGoals[indexPath.row].goalTitle
      if goalLabel.text!.count >= 20 && goalLabel.text!.count <= 23 {
        goalLabel.transform = CGAffineTransform(scaleX: 0.8, y: 0.8)
      } else if goalLabel.text!.count >= 24 {
        goalLabel.transform = CGAffineTransform(scaleX: 0.7, y: 0.7)
      }
      goalLabel.numberOfLines = 0
      goalLabel.lineBreakMode = .byWordWrapping
      goalLabel.textAlignment = .center
      // goalLabel.textColor = .black
      myCell.contentView.addSubview(goalLabel)
            
      NSLayoutConstraint.activate([
          myCell.centerXAnchor.constraint(equalTo: goalLabel.centerXAnchor),
          myCell.contentView.centerYAnchor.constraint(equalTo: goalLabel.centerYAnchor),
          goalLabel.trailingAnchor.constraint(equalTo: myCell.trailingAnchor, constant: 16),
          goalLabel.leadingAnchor.constraint(equalTo: myCell.leadingAnchor, constant: -16)
      ])
      
      myCell.layer.cornerRadius = 8
      myCell.backgroundColor = pomodoroSession?.accentColor.withAlphaComponent(0.3)
      myCell.layer.borderColor = pomodoroSession?.mainColor.withAlphaComponent(0.3).cgColor
      myCell.layer.borderWidth = 4
      return myCell
    }
}


// MARK: - UICollectionViewDelegate
extension MakePomodoroViewController: UICollectionViewDelegate {
 
  func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {

  }
  
  func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
    UIView.animate(withDuration: 0.3) {
      if let cell = self.goalsCollectionView.cellForItem(at: indexPath) {
        cell.transform = CGAffineTransform(scaleX: 0.95, y: 0.95)
      }
    }
  }

  func collectionView(_ collectionView: UICollectionView, didUnhighlightItemAt indexPath: IndexPath) {
    UIView.animate(withDuration: 0.4, delay: 0, usingSpringWithDamping: 0.6, initialSpringVelocity: 0.3, options: .curveEaseInOut, animations: {
      if let cell = self.goalsCollectionView.cellForItem(at: indexPath) {
        if !(self.pomodoroSession?.sessionGoals[indexPath.row].isComplete)! {
          cell.backgroundColor = (self.pomodoroSession?.accentColor)!.withAlphaComponent(0.5)
          cell.layer.borderColor = self.pomodoroSession?.mainColor.cgColor
          self.pomodoroSession?.sessionGoals[indexPath.row].isComplete.toggle()
        } else {
          cell.backgroundColor = (self.pomodoroSession?.accentColor)!.withAlphaComponent(0.3)
          cell.layer.borderColor = (self.pomodoroSession?.mainColor)!.withAlphaComponent(0.3).cgColor
          self.pomodoroSession?.sessionGoals[indexPath.row].isComplete.toggle()
        }
        self.animateRing(forPercentage: true)
        cell.transform = .identity
      }
    })
    let percentage = Int(activeGoals / Double((pomodoroSession?.sessionGoals.count)!) * 100)
    if activeGoals == Double((pomodoroSession?.sessionGoals.count)!) {
      messageGoalsLabel.text = "OH... MY... GOD! You've achieved all of your \(Int(activeGoals)) goals, you are a ROCKSTAR! 🤩"
    } else if activeGoals == 0 {
      messageGoalsLabel.text = "You have not achieved any of your \((pomodoroSession?.sessionGoals.count)!) goals, keep going! 😊"
    } else {
      messageGoalsLabel.text = MotivationMessage.randomMotivationMessage() + "\(Int(activeGoals)) of your \((pomodoroSession?.sessionGoals.count)!)" + MessageEnd.randomEndingMessage()
    }
    percentageLabel.textAlignment = .center
    percentageLabel.text = "\(percentage)%"
  }
}

// MARK: - UICollectionViewDelegateFlowLayout
extension MakePomodoroViewController: UICollectionViewDelegateFlowLayout {

    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 165, height: 50)
    }

    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 10, left: 0, bottom: 10, right: 0) //.zero
    }

    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }

    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
}

